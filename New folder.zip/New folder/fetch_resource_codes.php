<?php
include 'db_connect.php';

$resource_type_code = $_GET['resource_type_code'];

$sql = "SELECT resource_code FROM resources WHERE resource_type_code = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $resource_type_code);
$stmt->execute();
$result = $stmt->get_result();
$resource_codes = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($resource_codes);

$stmt->close();
$conn->close();
?>
<script>
document.getElementById('resource-type').addEventListener('change', function () {
    const resourceTypeCode = this.value;
    const resourceCodeSelect = document.getElementById('resource-code');

    fetch(`fetch_resource_codes.php?resource_type_code=${resourceTypeCode}`)
        .then(response => response.json())
        .then(data => {
            resourceCodeSelect.innerHTML = ''; // Clear existing options
            data.forEach(resource => {
                const option = document.createElement('option');
                option.value = resource.resource_code;
                option.text = resource.resource_code;
                resourceCodeSelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error:', error));
});
<script/>
