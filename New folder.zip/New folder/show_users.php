<?php
session_start();
include 'db_connect.php';

// Ensure the user is an admin
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 4) {
    echo "Access denied.";
    exit();
}

// Fetch all users with their roles
$sql = "SELECT u.user_id, u.username, r.role_name FROM users u JOIN roles r ON u.role_id = r.role_id";
$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - User List</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>User List</h2>
        <div class="logout">
            <a href="logout.php">Logout</a>
        </div>
        <?php
        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>User ID</th><th>Username</th><th>Role</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>" . htmlspecialchars($row["user_id"]) . "</td><td>" . htmlspecialchars($row["username"]) . "</td><td>" . htmlspecialchars($row["role_name"]) . "</td></tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No users found.</p>";
        }
        $conn->close();
        ?>
    </div>
</body>
</html>
