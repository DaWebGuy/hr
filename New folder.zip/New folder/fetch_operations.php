<?php
include 'db_connect.php';

$sql = "SELECT operation_code FROM operations";
$result = $conn->query($sql);
$operations = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($operations);

$conn->close();
?>
