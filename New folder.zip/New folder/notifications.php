<?php
include 'db_connect.php';

function notify($user_id, $message){
    global $conn;
    $stmt = $conn->prepare("INSERT INTO notifications (user_id, message, created_at) VALUEs (?, ?, NOW())");
    $stmt->bind_param("is", $user_id,$message);
    $stmt->execute();

    if ($stmt->affected_rows > 0){
        echo "notification sent!";
    }else{
        echo "failed to send notification";
    }
    $stmt->close();
}