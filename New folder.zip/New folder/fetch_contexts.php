<?php
include 'db_connect.php';

$sql = "SELECT context_code FROM contexts";
$result = $conn->query($sql);
$contexts = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($contexts);

$conn->close();
?>
