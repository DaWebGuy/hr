<?php
session_start();
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role_id = intval($_POST['role_id']);
    $recaptchaResponse = $_POST['g-recaptcha-response'];

    // Verify reCAPTCHA
    $secretKey = "6LcWBBoqAAAAAG0HXQcMg21vjVJecPNlDihLSNG9";
    $verifyResponse = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$recaptchaResponse");
    $responseData = json_decode($verifyResponse);

    if ($responseData->success) {
        // reCAPTCHA verified successfully
        $sql = "SELECT user_id, password FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id, $hashed_password);
            $stmt->fetch();
            if (password_verify($password, $hashed_password)) {
                $_SESSION['user_id'] = $user_id;
                $_SESSION['role_id'] = $role_id;

                $sql = "SELECT COUNT(*) FROM user_security_answers WHERE user_id = ? AND role_id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ii", $user_id, $role_id);
                $stmt->execute();
                $stmt->bind_result($count);
                $stmt->fetch();
                $stmt->close();

                if ($count == 0) {
                    header("Location: setup_security.php");
                } else {
                    $_SESSION['security_verified'] = false;
                    header("Location: verify_security.php");
                }
                exit();
            } else {
                $error_message = "Invalid password.";
            }
        } else {
            $error_message = "No user found.";
        }
        $stmt->close();
    } else {
        $error_message = "Robot verification failed, please try again.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body>
<div class="form_container">
        <h2>Login</h2>
        <form id="loginForm" action="login.php" method="post">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
            <label for="role_id">Role:</label>
        <select name="role_id" required>
            <option value="2">Patient</option>
            <option value="1">Doctor</option>
            <option value="3">Friend</option>
            <option value="4">Spouse</option>
            <option value="5">Admin</option>
        </select>
            </div>
        <div class="g-recaptcha" data-sitekey="6LcWBBoqAAAAABxDUNjfYSHN3VHyBDShoVU4as_3"></div>
        <button type="submit">Login</button>
        <p>Don't have an account? <a href="register.php">Sign up</a></p>
        <?php if (isset($error_message)): ?>
            <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>
    </form>
        </div>
</body>
</html>
