<?php
include 'db_connect.php';

$sql = "SELECT role_name FROM roles";
$result = $conn->query($sql);
$roles = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($roles);

$conn->close();
?>
