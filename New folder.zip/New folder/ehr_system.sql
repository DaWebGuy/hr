-- Create database
CREATE DATABASE ehr_system;

-- Use the created database
USE ehr_system;

-- Create roles table
CREATE TABLE roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL
);

-- Insert roles into the roles table
INSERT INTO roles (role_name) VALUES
('Doctor'),
('Patient'),
('Friend'),
('Spouse'),
('Admin');

-- Create users table
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    role_id INT,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

-- Create security_questions table
CREATE TABLE security_questions (
    question_id INT AUTO_INCREMENT PRIMARY KEY,
    role_id INT NOT NULL,
    question VARCHAR(255) NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

-- Create user_security_answers table
CREATE TABLE user_security_answers (
    user_id INT NOT NULL,
    role_id INT NOT NULL,
    question_id INT NOT NULL,
    answer VARCHAR(255) NOT NULL,
    PRIMARY KEY (user_id, role_id, question_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (role_id) REFERENCES roles(role_id),
    FOREIGN KEY (question_id) REFERENCES security_questions(question_id)
);

-- Insert security questions into the security_questions table
INSERT INTO security_questions (question, role_id) VALUES
('What is your medical specialty?', 1),
('What is the name of your first patient?', 1),
('What is your favorite medical book?', 1),
('What is your mother’s maiden name?', 2),
('What was the name of your first school?', 2),
('What was the name of your first pet?', 2),
('Where did you and your friend meet?', 3),
('What is your friend’s middle name?', 3),
('What is your favorite shared activity?', 3),
('What is your spouse’s birth date?', 4),
('Where did you meet your spouse?', 4),
('What is your anniversary date?', 4),
('What is the name of your first pet?', 5),
('What was the name of your first school?', 5),
('What is your favorite book?', 5);

-- Create patients table
CREATE TABLE patients (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_name VARCHAR(255) NOT NULL
);

CREATE TABLE medical_results (
    result_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    test_name VARCHAR(255),
    test_result TEXT,
    test_date DATE,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create resources table
CREATE TABLE resources (
    resource_id INT AUTO_INCREMENT PRIMARY KEY,
    resource_type_code VARCHAR(255) NOT NULL,
    resource_code VARCHAR(255) NOT NULL
);

-- Create operations table
CREATE TABLE operations (
    operation_id INT AUTO_INCREMENT PRIMARY KEY,
    operation_code VARCHAR(255) NOT NULL
);

-- Create contexts table
CREATE TABLE contexts (
    context_id INT AUTO_INCREMENT PRIMARY KEY,
    context_code VARCHAR(255) NOT NULL
);

-- Create permissions table
CREATE TABLE permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    role_id INT NOT NULL,
    resource_id INT NOT NULL,
    operation_id INT NOT NULL,
    context_id INT NOT NULL,
    is_permitted BOOLEAN NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (role_id) REFERENCES roles(role_id),
    FOREIGN KEY (resource_id) REFERENCES resources(resource_id),
    FOREIGN KEY (operation_id) REFERENCES operations(operation_id),
    FOREIGN KEY (context_id) REFERENCES contexts(context_id)
);

create TABLE notifications (
    id INT  AUTO_INCREMENT PRIMARY KEY,
    user_id INT not null,
    message TEXT not null,
    is_read BOOLEAN not null,
    created_at Timestamp DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Insert data into patients table
INSERT INTO patients (patient_name) VALUES
('Margret Jones'),
('John Doe'),
('Alice Smith');

-- Insert data into resources table
INSERT INTO resources (resource_type_code, resource_code) VALUES
('AllMedicationListData', 'Med001'),
('AllMedicationListData', 'Med002'),
('AllMedicationListData', 'Med003');

-- Insert data into operations table
INSERT INTO operations (operation_code) VALUES
('ReadCurrent');

-- Insert data into contexts table
INSERT INTO contexts (context_code) VALUES
('AllApplications');

-- Insert data into permissions table
INSERT INTO permissions (patient_id, role_id, resource_id, operation_id, context_id, is_permitted) VALUES 
(1, 4, 1, 1, 1, TRUE), -- Margret Jones, Spouse, AllMedicationListData, ReadCurrent, AllApplications
(2, 1, 2, 1, 1, TRUE), -- John Doe, Doctor, AllMedicationListData, ReadCurrent, AllApplications
(3, 2, 3, 1, 1, TRUE); -- Alice Smith, Nurse, AllMedicationListData, ReadCurrent, AllApplications

-- SQL Query
SELECT 
    p.patient_name AS "Patient name",
    r.role_name AS "User Type",
    res.resource_type_code AS "Resource Type Code",
    res.resource_code AS "Resource Code",
    op.operation_code AS "Operation Code",
    ctx.context_code AS "Context Code",
    CASE WHEN perm.is_permitted THEN 'Permitted' ELSE 'Denied' END AS "Operation Status",
    NOW() AS "Query Timestamp"
FROM 
    permissions perm
JOIN 
    patients p ON perm.patient_id = p.patient_id
JOIN 
    roles r ON perm.role_id = r.role_id
JOIN 
    resources res ON perm.resource_id = res.resource_id
JOIN 
    operations op ON perm.operation_id = op.operation_id
JOIN 
    contexts ctx ON perm.context_id = ctx.context_id
WHERE 
    p.patient_name = 'Margret Jones'
    AND r.role_name = 'Spouse'
    AND res.resource_type_code = 'AllMedicationListData'
    AND op.operation_code = 'ReadCurrent'
    AND ctx.context_code = 'AllApplications';
