<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['security_verified']) || !$_SESSION['security_verified']) {
    header("Location: verify_security.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch the full name of the current user
$sql = "SELECT full_name FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($full_name);
$stmt->fetch();
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
    <h2>Welcome, <?php echo htmlspecialchars($full_name); ?></h2>
        <div class="logout">
            <a href="logout.php">Logout</a>
        </div>
        <div class="dashboard">
            <div class="tile"><a href="appointments.php"><img src="icons/appointments.png" alt="Appointments"><span>Appointments</span></a></div>
            <div class="tile"><a href="messaging.php"><img src="icons/messaging.png" alt="Messaging"><span>Messaging</span></a></div>
            <div class="tile"><a href="medication.php"><img src="icons/medication.png" alt="Medication"><span>Medication</span></a></div>
            <div class="tile"><a href="results_reports.php"><img src="icons/results.png" alt="Results/Reports"><span>Results/Reports</span></a></div>
            <div class="tile"><a href="immunisations.php"><img src="icons/immunisations.png" alt="Immunisations"><span>Immunisations"></span></a></div>
            <div class="tile"><a href="allergies.php"><img src="icons/allergies.png" alt="Allergies"><span>Allergies"></span></a></div>
            <div class="tile"><a href="vitals.php"><img src="icons/vitals.png" alt="Vitals"><span>Vitals</span></a></div>
            <div class="tile"><a href="reminders.php"><img src="icons/reminders.png" alt="Reminders"><span>Reminders"></span></a></div>
            <div class="tile"><a href="resources.php"><img src="icons/resources.png" alt="Resources"><span>Resources"></span></a></div>
            <div class="tile"><a href="account.php"><img src="icons/account.png" alt="Account"><span>Account"></span></a></div>
            <div class="tile"><a href="timeline.php"><img src="icons/timeline.png" alt="Timeline"><span>Timeline"></span></a></div>
            <div class="tile"><a href="profile.php"><img src="icons/profile.png" alt="Profile"><span>Profile"></span></a></div>
            <div class="tile"><a href="query.php"><img src="icons/settings.png" alt="Settings"><span>Settings"></span></a></div>
        </div>
    </div>
</body>
</html>
