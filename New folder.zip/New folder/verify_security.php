<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role_id = $_SESSION['role_id'];

$sql = "SELECT question_id, question FROM security_questions WHERE role_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $role_id);
$stmt->execute();
$result = $stmt->get_result();
$questions = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $all_correct = true;
    foreach ($questions as $question) {
        $question_id = $question['question_id'];
        $user_answer = $_POST['question_' . $question_id];
        $sql = "SELECT answer FROM user_security_answers WHERE user_id = ? AND question_id = ? AND role_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iii", $user_id, $question_id, $role_id);
        $stmt->execute();
        $stmt->bind_result($correct_answer);
        $stmt->fetch();
        if ($user_answer !== $correct_answer) {
            $all_correct = false;
            break;
        }
        $stmt->close();
    }

    if ($all_correct) {
        $_SESSION['security_verified'] = true;
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Incorrect answers.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Security Verification</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <form method="post" action="">
        <?php foreach ($questions as $question): ?>
            <label for="question_<?php echo $question['question_id']; ?>"><?php echo $question['question']; ?></label>
            <input type="text" name="question_<?php echo $question['question_id']; ?>" required>
        <?php endforeach; ?>
        <button type="submit">Verify</button>
    </form>
</body>
</html>
