<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role_id = $_SESSION['role_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['questions']) && is_array($_POST['questions'])) {
        foreach ($_POST['questions'] as $question_id => $answer) {
            $sql = "INSERT INTO user_security_answers (user_id, role_id, question_id, answer) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("iiis", $user_id, $role_id, $question_id, $answer);
                if (!$stmt->execute()) {
                    echo "Error: " . $stmt->error;
                }
                $stmt->close();
            } else {
                echo "Error preparing statement: " . $conn->error;
            }
        }
        $_SESSION['security_verified'] = true;
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Please answer all questions.";
    }
}

$sql = "SELECT question_id, question FROM security_questions WHERE role_id = ?";
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("i", $role_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $questions = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} else {
    echo "Error preparing statement: " . $conn->error;
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Setup Security Questions</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Setup Security Questions</h2>
        <form method="post" action="">
            <?php foreach ($questions as $question): ?>
                <label for="question_<?php echo $question['question_id']; ?>"><?php echo htmlspecialchars($question['question']); ?></label>
                <input type="text" name="questions[<?php echo $question['question_id']; ?>]" required>
            <?php endforeach; ?>
            <button type="submit">Set Up Security Questions</button>
        </form>
    </div>
</body>
</html>
