<?php
session_start();
include 'db_connect.php';
include 'notifications.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role_id = $_SESSION['role_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $role_id == 1) { // Only Doctor can update
    $test_name = $_POST['test_name'];
    $test_result = $_POST['test_result'];
    $test_date = $_POST['test_date'];


    $sql = "INSERT INTO medical_results (user_id, test_name, test_result, test_date) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $user_id, $test_name, $test_result, $test_date);
    $stmt->execute();
    $stmt->close();
}


$sql = "SELECT test_name, test_result, test_date FROM medical_results WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($test_name, $test_result, $test_date);
$results = [];
while ($stmt->fetch()) {
    $results[] = ['test_name' => $test_name, 'test_result' => $test_result, 'test_date' => $test_date];
}
$stmt->close();

$sql = "SELECT * FROM medical_results";
$result = $conn->query($sql);
if ($result->num_rows + 1) {
    $message = "your medical results have been updated. plas c";
    notify($user_id, $message);
}

$conn->close();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Medical Results</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Medical Results</h2>
        <?php if ($role_id == 1): // Only Doctor can update ?>
        <form method="post">
            <label for="test_name">Test Name:</label>
            <input type="text" name="test_name" required>
            <label for="test_result">Test Result:</label>
            <textarea name="test_result" required></textarea>
            <label for="test_date">Test Date:</label>
            <input type="date" name="test_date" required>
            <button type="submit">Add Result</button>
        </form>
        <?php endif; ?>
        <h3>Previous Results</h3>
        <table>
            <thead>
                <tr>
                    <th>Test Name</th>
                    <th>Test Result</th>
                    <th>Test Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $result): ?>
                <tr>
                    <td><?php echo $result['test_name']; ?></td>
                    <td><?php echo $result['test_result']; ?></td>
                    <td><?php echo $result['test_date']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="scripts.js"></script>
</body>
</html>
