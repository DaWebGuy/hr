<?php
session_start();
include 'db_connect.php';
include 'notifications.php';

$note = [];
$sql = "SELECT * FROM notifications";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
$note[]= $row;

}}

$tr = "";

for ($i=0; $i < count($note) ; $i++) { 
    $id = $note[$i]["id"] ;
    $message = $note[$i]["message"];
$tr .= "<tr> 
        <td> $id</td>
        <td> $message </td>
    </tr>";
    
  }

    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reminders</title>
</head>
<body>
<h2>All notifications</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Message</th>
    </tr>
    <?php
       echo $tr;
    ?>
</table>

</body>
</html>