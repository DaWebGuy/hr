<?php
session_start();
include 'db_connect.php';

// Check if user is logged in, otherwise redirect to login page
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$full_name = '';
$roles = [];
$resource_types = [];
$operations = [];
$contexts = [];

// Fetch the full name of the current user
$user_id = $_SESSION['user_id'];
$sql = "SELECT full_name FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($full_name);
$stmt->fetch();
$stmt->close();

// Fetch roles
$sql = "SELECT role_id, role_name FROM roles";
$result = $conn->query($sql);

//print_r  ($result);

if ($result) {
    $roles = $result->fetch_all(MYSQLI_ASSOC);
    //print_r ($roles);
    $result->close();
}

// Fetch resource types
$sql = "SELECT DISTINCT resource_type_code FROM resources";
$result = $conn->query($sql);
if ($result) {
    $resource_types = $result->fetch_all(MYSQLI_ASSOC);
    $result->close();
}

// Fetch operation codes
$sql = "SELECT operation_id, operation_code FROM operations";
$result = $conn->query($sql);
if ($result) {
    $operations = $result->fetch_all(MYSQLI_ASSOC);
    $result->close();
}

// Fetch context codes
$sql = "SELECT context_id, context_code FROM contexts";
$result = $conn->query($sql);
if ($result) {
    $contexts = $result->fetch_all(MYSQLI_ASSOC);
    
}

$conn->close();

$status = '';
$rows = '';
$startTime = '';
$endTime = '';
$executionTime = '';

//function executeQuery(){
 //global $result;
//if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $startTime = microtime(true);
    $startRTime = date("Y, m, d, H: i: s");
    $rows = $result->num_rows > 0;
    $status = 'success';
    $endTime = microtime(true);
    $endRTime = date("Y, m, d, H: i: s");
    $executionTime = $endTime - $startTime;
//}
$result->close();
//}
//executeQuery()

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Query Interface</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <form id="queryForm">
            <div class="form-group">
                <label for="patient-name">Patient name:</label>
                <input type="text" id="patient-name" name="patient-name" value="<?php echo htmlspecialchars($full_name); ?>" readonly>
            </div>
            <div class="form-group">
                <label for="user-type">User Type:</label>
                <select id="user-type" name="user-type" required>
                    <?php foreach ($roles as $role): ?>
                        <option value="<?php echo htmlspecialchars($role['role_name']); ?>"><?php echo htmlspecialchars($role['role_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="resource-type">Resource Type Code:</label>
                <select id="resource-type" name="resource-type" required>
                    <?php foreach ($resource_types as $resource_type): ?>
                        <option value="<?php echo htmlspecialchars($resource_type['resource_type_code']); ?>"><?php echo htmlspecialchars($resource_type['resource_type_code']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="resource-code">Resource Code:</label>
                <input type="text" id="resource-code" name="resource-code">
            </div>
            <div class="form-group">
                <label for="operation-code">Operation Code:</label>
                <select id="operation-code" name="operation-code" required>
                    <?php foreach ($operations as $operation): ?>
                        <option value="<?php echo htmlspecialchars($operation['operation_code']); ?>"><?php echo htmlspecialchars($operation['operation_code']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="context-code">Context Code:</label>
                <select id="context-code" name="context-code" required>
                    <?php foreach ($contexts as $context): ?>
                        <option value="<?php echo htmlspecialchars($context['context_code']); ?>"><?php echo htmlspecialchars($context['context_code']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="button" > Execute Query</button>
        </form>
        <div class="query-result" id="queryResult">
            <h3>QUERY RESULT</h3>
            <p><strong>Operation Status:</strong> <span id="status"><?php echo $status; ?></span></p>
            <p><strong>Returned Rows:</strong> <span id="rows"></span><?php echo $rows; ?></p>
            <p><strong>Start Time:</strong> <span id="startRTime"><?php echo $startRTime; ?></span></p>
            <p><strong>End Time:</strong> <span id="endRTime"><?php echo $endRTime; ?></span></p>
            <p><strong>Total Execution Time (milliseconds):</strong> <span id="executionTime"><?php echo $executionTime; ?></span></p>
        </div>
    </div>

</body>
</html>
