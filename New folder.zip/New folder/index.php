<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to EHR.com</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Welcome to EHR System</h2>
        <div class="link-box">
        <a href="register.php" class="btn">Register</a>
        <a href="login.php" class="btn">Login</a>
</div>
    </div>
</body>
</html>
