<?php
include 'db_connect.php';

$sql = "SELECT DISTINCT resource_type_code FROM resources";
$result = $conn->query($sql);
$resource_types = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($resource_types);

$conn->close();
?>
